import React from 'react'
import { Lines } from 'react-preloaders';

const Preloader = () => {
  return (
    <div>Preloader</div>
  )
}

export default Preloader