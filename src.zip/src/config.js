module.exports = {
    apiBaseUrl: 'http://banoqabil.azurewebsites.net/api'
}